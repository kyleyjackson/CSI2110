kyle jackson - 300425781 - kjack086@uottawa.ca

- changed some constructors (is that ok?)
- everything should work